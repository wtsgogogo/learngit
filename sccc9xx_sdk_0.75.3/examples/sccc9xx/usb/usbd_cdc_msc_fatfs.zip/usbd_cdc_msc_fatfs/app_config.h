#ifndef APP_CONFIG_H_
#define APP_CONFIG_H_

#define SDK_HCLK_MHZ (64)

#define SDK_HSE_USED (1)


#endif
